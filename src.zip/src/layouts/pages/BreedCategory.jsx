import { useParams } from "react-router-dom"

import breedData from "../../data/breeds"

import BreedSlider from "../../components/breeds/BreedSlider"

import Navbar from "../../components/Navbar"

import Footer from "../../components/Footer"

const BreedCategory = () => {

  const { pet } = useParams()

  const filteredBreeds = breedData.filter(
    (item) => item.category === pet
  )

  return (

    <div className="bg-[#f8f8f8] min-h-screen">

      <Navbar />

      <div className="py-16">

        <h1 className="text-5xl font-bold text-center mb-14 capitalize">

          {pet} Breeds

        </h1>

        <BreedSlider
          title={`Popular ${pet} Breeds`}
          breeds={filteredBreeds}
        />

      </div>

      <Footer />

    </div>

  )
}

export default BreedCategory