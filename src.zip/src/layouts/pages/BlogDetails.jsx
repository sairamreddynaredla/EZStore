import { useParams } from "react-router-dom";
import breedData from "../../data/breeds";
import BreedHero from "../../components/breeds/BreedHero";
import BreedInfo from "../../components/breeds/BreedInfo";
import BreedNutrition from "../../components/breeds/BreedNutrition";
import BreedGrooming from "../../components/breeds/BreedGrooming";
import BreedFAQ from "../../components/breeds/BreedFaq";
import BreedSlider from "../../components/breeds/BreedSlider";

const BreedDetails = () => {
  const { slug } = useParams();

  const breed = breedData.find((b) => b.slug === slug);

  if (!breed) {
    return (
      <div className="text-center py-20 text-3xl font-bold text-gray-400">
        🐾 Breed Not Found
      </div>
    );
  }

  // Build info object from breed.info or breed.overview (Golden Retriever uses overview)
  const infoData = {
    size:      breed.info?.size      || breed.overview?.size      || "—",
    lifespan:  breed.info?.lifespan  || breed.overview?.lifespan  || "—",
    weight:    breed.info?.weight    || breed.overview?.weight    || "—",
    grooming:  breed.info?.grooming  || breed.overview?.shedding  || breed.info?.shedding || "—",
  };

  // Other breeds from same category for the slider
  const otherBreeds = breedData.filter(
    (b) => b.slug !== slug && b.category === breed.category
  );

  return (
    <div className="max-w-6xl mx-auto px-6 py-10">

      {/* HERO */}
      <BreedHero breed={breed} />

      {/* AT A GLANCE */}
      <BreedInfo breed={infoData} />

      {/* NUTRITION */}
      {breed.nutrition && <BreedNutrition breed={breed} />}

      {/* GROOMING */}
      {breed.grooming && <BreedGrooming breed={breed} />}

      {/* TRAINING - same style as Grooming (bg yellow-ish) */}
      {breed.training && (
        <section className="mt-14 px-6">
          <div className="bg-[#dce8f9] rounded-[30px] p-10">
            <h2 className="text-4xl font-bold mb-10">
              {breed.training.title}
            </h2>
            <div className="grid md:grid-cols-2 gap-10 items-center">
              <div>
                <img
                  src={breed.training.image}
                  alt={breed.name}
                  className="w-full rounded-[24px] object-cover"
                />
              </div>
              <div className="space-y-4">
                {breed.training.trainingTips?.map((item, i) => (
                  <div key={i} className="bg-white rounded-[20px] p-5 border">
                    <h3 className="font-semibold text-lg">{item}</h3>
                  </div>
                ))}
                {breed.training.tips?.map((item, i) => (
                  <div key={i} className="bg-white rounded-[20px] p-5 border">
                    <h3 className="font-semibold text-lg">{item}</h3>
                  </div>
                ))}
                {breed.training.activities && (
                  <div className="flex flex-wrap gap-3 mt-4">
                    {breed.training.activities.map((act, i) => (
                      <span
                        key={i}
                        className="bg-white border rounded-full px-5 py-2 font-semibold text-sm"
                      >
                        {act}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* LIFESTYLE */}
      {breed.lifestyle && (
        <section className="mt-14 px-6">
          <div className="bg-[#f0e6ff] rounded-[30px] p-10">
            <h2 className="text-4xl font-bold mb-10">
              {breed.lifestyle.title}
            </h2>
            <div className="grid md:grid-cols-2 gap-10 items-center">
              <div>
                <img
                  src={breed.lifestyle.bannerImage || breed.lifestyle.image}
                  alt={breed.name}
                  className="w-full rounded-[24px] object-cover"
                />
              </div>
              <div className="space-y-4">
                {breed.lifestyle.dailyRoutine?.map((item, i) => (
                  <div key={i} className="bg-white rounded-[20px] p-5 border">
                    <h3 className="font-semibold text-lg">{item}</h3>
                  </div>
                ))}
                {breed.lifestyle.tips?.map((item, i) => (
                  <div key={i} className="bg-white rounded-[20px] p-5 border">
                    <h3 className="font-semibold text-lg">{item}</h3>
                  </div>
                ))}
                {breed.lifestyle.essentials && (
                  <div>
                    <p className="font-bold text-lg mb-3 mt-2">Essentials</p>
                    <div className="flex flex-wrap gap-3">
                      {breed.lifestyle.essentials.map((item, i) => (
                        <span
                          key={i}
                          className="bg-white border rounded-full px-5 py-2 font-semibold text-sm"
                        >
                          {item}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* FUN FACTS */}
      {breed.funFacts && breed.funFacts.length > 0 && (
        <section className="mt-14 px-6">
          <div className="bg-[#fff3cd] rounded-[30px] p-10">
            <h2 className="text-4xl font-bold mb-8">🎉 Fun Facts</h2>
            <div className="grid md:grid-cols-2 gap-5">
              {breed.funFacts.map((fact, i) => (
                <div key={i} className="bg-white rounded-[20px] p-5 border flex gap-4 items-start">
                  <span className="text-2xl">✨</span>
                  <p className="text-gray-700 leading-7">{fact}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* FAQs */}
      {breed.faq && breed.faq.length > 0 && <BreedFAQ breed={breed} />}

      {/* BREEDS SLIDER */}
      {otherBreeds.length > 0 && <BreedSlider breeds={otherBreeds} />}

    </div>
  );
};

export default BreedDetails;