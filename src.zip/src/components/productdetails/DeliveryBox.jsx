const DeliveryBox = () => {
  return (
    <div className="bg-white p-6 rounded-3xl shadow">
      Fast Delivery Available 🚚
    </div>
  )
}

export default DeliveryBox