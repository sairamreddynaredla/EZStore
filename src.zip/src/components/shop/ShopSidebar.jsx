
import FilterSection from "./FilterSection";

const ShopSidebar = () => {
  return (
    <aside
      className="
      w-[280px]
      shrink-0
      sticky
      top-24
      h-fit
      bg-white
      border border-gray-200
      rounded-xl
      p-5
      overflow-y-auto
      max-h-[90vh]
      shadow-sm
    "
    >
      <h2 className="text-[28px] font-semibold text-black mb-8">
        Filter By
      </h2>

      <FilterSection title="Availability">
        <label className="flex items-center gap-3 text-sm text-gray-700 cursor-pointer hover:text-black">
          <input
            type="checkbox"
            className="w-4 h-4 rounded border-gray-300"
          />
          Include Out Of Stock
        </label>
      </FilterSection>

      <FilterSection title="Price">
        <input
          type="range"
          className="w-full accent-yellow-500 cursor-pointer"
        />

        <div className="flex justify-between text-xs text-gray-500 mt-2">
          <span>₹100</span>
          <span>₹5000</span>
        </div>

        <button
          className="
          w-full
          bg-yellow-400
          hover:bg-yellow-500
          text-black
          font-medium
          py-2
          rounded-full
          mt-4
          border border-yellow-500
        "
        >
          Apply Filters
        </button>
      </FilterSection>

      <FilterSection title="Pet Type">
        <label className="flex items-center gap-3 text-sm text-gray-700 cursor-pointer hover:text-black">
          <input
            type="checkbox"
            className="w-4 h-4 rounded border-gray-300"
          />
          Dog
        </label>

        <label className="flex items-center gap-3 text-sm text-gray-700 cursor-pointer hover:text-black">
          <input
            type="checkbox"
            className="w-4 h-4 rounded border-gray-300"
          />
          Cat
        </label>
      </FilterSection>

      <FilterSection title="Brands">
        <label className="flex items-center gap-3 text-sm text-gray-700 cursor-pointer hover:text-black">
          <input
            type="checkbox"
            className="w-4 h-4 rounded border-gray-300"
          />
          Royal Canin
        </label>

        <label className="flex items-center gap-3 text-sm text-gray-700 cursor-pointer hover:text-black">
          <input
            type="checkbox"
            className="w-4 h-4 rounded border-gray-300"
          />
          Drools
        </label>

        <label className="flex items-center gap-3 text-sm text-gray-700 cursor-pointer hover:text-black">
          <input
            type="checkbox"
            className="w-4 h-4 rounded border-gray-300"
          />
          Pedigree
        </label>

        <label className="flex items-center gap-3 text-sm text-gray-700 cursor-pointer hover:text-black">
          <input
            type="checkbox"
            className="w-4 h-4 rounded border-gray-300"
          />
          Farmina
        </label>
      </FilterSection>

      <FilterSection title="Flavor">
        <label className="flex items-center gap-3 text-sm text-gray-700 cursor-pointer hover:text-black">
          <input
            type="checkbox"
            className="w-4 h-4 rounded border-gray-300"
          />
          Chicken
        </label>

        <label className="flex items-center gap-3 text-sm text-gray-700 cursor-pointer hover:text-black">
          <input
            type="checkbox"
            className="w-4 h-4 rounded border-gray-300"
          />
          Fish
        </label>

        <label className="flex items-center gap-3 text-sm text-gray-700 cursor-pointer hover:text-black">
          <input
            type="checkbox"
            className="w-4 h-4 rounded border-gray-300"
          />
          Lamb
        </label>
      </FilterSection>

      <FilterSection title="Weight">
        <label className="flex items-center gap-3 text-sm text-gray-700 cursor-pointer hover:text-black">
          <input
            type="checkbox"
            className="w-4 h-4 rounded border-gray-300"
          />
          1kg
        </label>

        <label className="flex items-center gap-3 text-sm text-gray-700 cursor-pointer hover:text-black">
          <input
            type="checkbox"
            className="w-4 h-4 rounded border-gray-300"
          />
          3kg
        </label>

        <label className="flex items-center gap-3 text-sm text-gray-700 cursor-pointer hover:text-black">
          <input
            type="checkbox"
            className="w-4 h-4 rounded border-gray-300"
          />
          10kg
        </label>
      </FilterSection>

      <FilterSection title="Pet Life Stages">
        <label className="flex items-center gap-3 text-sm text-gray-700 cursor-pointer hover:text-black">
          <input
            type="checkbox"
            className="w-4 h-4 rounded border-gray-300"
          />
          Puppy
        </label>

        <label className="flex items-center gap-3 text-sm text-gray-700 cursor-pointer hover:text-black">
          <input
            type="checkbox"
            className="w-4 h-4 rounded border-gray-300"
          />
          Adult
        </label>

        <label className="flex items-center gap-3 text-sm text-gray-700 cursor-pointer hover:text-black">
          <input
            type="checkbox"
            className="w-4 h-4 rounded border-gray-300"
          />
          Senior
        </label>
      </FilterSection>
    </aside>
  );
};

export default ShopSidebar;
