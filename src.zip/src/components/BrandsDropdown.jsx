import React, { useState } from "react";
import { brands } from "../data/brands";
import { useNavigate } from "react-router-dom";

const BrandsDropdown = () => {
  const [search, setSearch] = useState("");
  const navigate = useNavigate();


  const filteredBrands = brands.filter(b =>
    b.name.toLowerCase().includes(search.toLowerCase())
  );
  const popularBrands = brands.filter(b => b.featured);

  // Dynamically import all brand images from assets/brands
  const brandImages = import.meta.glob('../assets/brands/*.jpeg', { eager: true, as: 'url' });

  const getBrandImage = (logo) => {
    if (!logo || logo.trim() === '') return '/src/assets/brands/default.jpeg';
    const key = `../assets/brands/${logo}.jpeg`;
    return brandImages[key] || '/src/assets/brands/default.jpeg';
  };

  const handleBrandClick = (brand) => {
    const slug = brand.logo || brand.name.toLowerCase().replace(/\s+/g, '-');
    navigate(`/brands/${slug}`);
  };

  return (
    <div className="absolute left-1/2 top-full mt-2 -translate-x-1/2 w-[800px] bg-white shadow-2xl rounded-xl z-50 p-8 border border-gray-100">
      <div className="mb-4 flex flex-col items-center">
        <h2 className="text-xl font-bold mb-2 text-center">Popular Brands</h2>
        <div className="grid grid-cols-5 gap-6 mb-6">
          {popularBrands.map((brand) => (
            <div
              key={brand.id}
              className="flex flex-col items-center cursor-pointer hover:scale-105 transition"
              onClick={() => handleBrandClick(brand)}
            >
              <img
                src={getBrandImage(brand.logo)}
                alt={brand.name}
                className="w-16 h-16 object-contain mb-2 rounded-lg border border-gray-100 shadow bg-white"
                onError={e => {
                  e.target.onerror = null;
                  e.target.src = '/src/assets/brands/default.jpeg';
                }}
              />
              <span className="text-xs font-medium text-center">{brand.name}</span>
            </div>
          ))}
        </div>
        <h2 className="text-lg font-semibold mb-2 text-center">All Brands</h2>
      </div>
      <div className="grid grid-cols-6 gap-4 max-h-64 overflow-y-auto">
        {filteredBrands.map((brand) => (
          <div
            key={brand.id}
            className="flex flex-col items-center cursor-pointer hover:scale-105 transition"
            onClick={() => handleBrandClick(brand)}
          >
            <img
              src={getBrandImage(brand.logo)}
              alt={brand.name}
              className="w-12 h-12 object-contain mb-1 rounded-lg border border-gray-100 shadow bg-white"
              onError={e => {
                e.target.onerror = null;
                e.target.src = '/src/assets/brands/default.jpeg';
              }}
            />
            <span className="text-xs font-medium text-center">{brand.name}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BrandsDropdown;
