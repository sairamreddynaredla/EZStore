// Example: Golden Retriever detailed data for new layout
const dogBreedsDetails = [
  {
    slug: "golden-retriever",
    banner: {
      image: "/src/assets/breeds/golden-retriever.png",
      title: "Meet the Golden Retriever!",
      subtitle: "The Ultimate Companion for Fun & Joy!",
      traits: ["Intelligent", "Friendly", "Devoted"],
      description:
        "Loyal, loving, and always up for a game of fetch, the Golden Retriever is one of the world's most adored dog breeds. Perfect for families, therapy work, and active homes, Goldens thrive on love, play, and companionship.",
    },
    atAGlance: [
      { label: "Size", value: "Large" },
      { label: "Shedding", value: "Heavy, year-round" },
      { label: "Life Expectancy", value: "10–12 years" },
      { label: "Coat Type", value: "Dense double coat" },
      { label: "Temperament", value: "Friendly, loyal, intelligent" },
      { label: "Weight", value: "Male: 29–34 kg, Female: 25–29.5 kg" },
      { label: "Weather Tolerance", value: "-6°C to 30°C" },
      { label: "Suitable For", value: "Families, first-time owners" },
    ],
    sections: [
      {
        id: "nutrition",
        title: "Golden Retriever Nutrition",
        image: "/src/assets/breeds/golden-nutrition.png",
        content: {
          text: "Well-balanced, nutrient-rich diets to support their high energy, joint health, and coat condition.",
          list: [
            "High-quality animal protein (like chicken, lamb, fish)",
            "Omega fatty acids for skin and coat health",
            "Glucosamine & chondroitin for joint protection",
            "Moderate fat & calories to avoid obesity",
            "Added antioxidants & vitamins for immune support"
          ],
          table: {
            headers: ["Age", "Daily Quantity", "Meals per Day", "Feeding Tips"],
            rows: [
              ["Puppy (2–6 months)", "3–4 cups food", "3–4", "Use large-breed puppy formula for controlled growth"],
              ["Puppy (6–12 months)", "4–5 cups food", "2–3", "Gradually reduce to adult feeding schedule"],
              ["Adult (1–7 years)", "4–6 cups food", "2", "Adjust portion sizes based on activity level"],
              ["Senior (7+ years)", "3–4 cups food", "2", "Switch to senior formulas with joint support and lower calories"]
            ]
          }
        },
      },
      {
        id: "training",
        title: "Training & Exercise",
        image: "/src/assets/breeds/golden-training.png",
        content: {
          text: "Golden Retrievers are intelligent, eager-to-please, and quick learners.",
          list: [
            "Prevents behavioral issues like chewing or jumping",
            "Builds trust and improves responsiveness",
            "Start training as early as 8 weeks old",
            "Use positive reinforcement (praise, treats)",
            "Teach basic commands: sit, stay, come, leash walking",
            "Add enrichment: agility training, trick learning, obedience games"
          ]
        },
      },
      {
        id: "puppy-care",
        title: "Puppy Care For Golden Retriever",
        image: "/src/assets/breeds/golden-puppy.png",
        content: {
          text: "Golden Retriever puppies are adorable bundles of energy—but they need the right setup from day one.",
          list: [
            "Puppy-proof home: hide cords, secure cleaning supplies, remove small objects",
            "Set up a crate or quiet corner for naps and routine",
            "Provide chew toys to ease teething",
            "Vet visit within the first week",
            "Deworming and vaccine schedule",
            "Begin socialization with new people, sounds, and surfaces",
            "Stick to a routine for meals, potty breaks, and naps"
          ]
        },
      },
      {
        id: "lifestyle",
        title: "Golden Retriever Lifestyle",
        image: "/src/assets/breeds/golden-lifestyle.png",
        content: {
          text: "Goldens thrive in active homes with plenty of play, exercise, and companionship. They are popular therapy and guide dogs, and one of the most Instagrammed breeds in the world."
        },
      },
    ],
    trivia: [
      "Golden Retrievers starred in Air Bud, the hit sports movie franchise.",
      "Known for their gentle temperament, Goldens are popular therapy and guide dogs.",
      "One of the most Instagrammed breeds in the world—because who can resist that smile?",
    ],
    faqs: [
      { q: "What type of food is best for my Golden Retriever pet?", a: "High-quality animal protein, moderate fat, and breed-specific formulas are best." },
      { q: "How much exercise does a Golden Retriever need?", a: "At least 1-2 hours of active play and walks daily." },
      { q: "What common health issues should I watch for?", a: "Hip dysplasia, elbow dysplasia, and certain heart conditions are common." },
    ],
    breedsList: [
      { name: "Rottweiler", image: "/src/assets/breeds/rottweiler.png" },
      { name: "Beagle", image: "/src/assets/breeds/beagle.png" },
      { name: "Shih Tzu", image: "/src/assets/breeds/shihtzu.png" },
      { name: "Doberman", image: "/src/assets/breeds/doberman.png" },
      { name: "Pomeranian", image: "/src/assets/breeds/pomeranian.png" },
      { name: "Cocker Spaniel", image: "/src/assets/breeds/cocker.png" },
      { name: "German Shepherd", image: "/src/assets/breeds/germanshepherd.png" },
      { name: "Labrador Retriever", image: "/src/assets/breeds/labrador.png" },
      { name: "Golden Retriever", image: "/src/assets/breeds/golden-retriever.png" },
    ],
  },
];

export default dogBreedsDetails;
