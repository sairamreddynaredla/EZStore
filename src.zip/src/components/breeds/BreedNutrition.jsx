const BreedNutrition = ({ breed }) => {

  return (

    <section className="mt-12 px-6">

      <div className="bg-[#c9e7c2] rounded-[30px] p-10">

        <h2 className="text-4xl font-bold mb-6">

          {breed?.nutrition?.title}

        </h2>

        <div className="grid md:grid-cols-2 gap-10 items-center">

          {/* IMAGE */}

          <div>

            <img
              src={breed?.nutrition?.image}
              alt={breed?.name}
              className="w-full rounded-[24px] object-cover"
            />

          </div>

          {/* CONTENT */}

          <div>

            <p className="text-lg text-gray-700 leading-8 mb-8">

              {breed?.nutrition?.description}

            </p>

            <div className="space-y-4">

              {breed?.nutrition?.tips?.map((item, index) => (

                <div
                  key={index}
                  className="bg-white rounded-[20px] p-5 border"
                >

                  <h3 className="font-semibold text-lg">

                    {item}

                  </h3>

                </div>

              ))}

            </div>

          </div>

        </div>

      </div>

    </section>

  )
}

export default BreedNutrition