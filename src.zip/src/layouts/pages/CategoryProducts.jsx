import { useState } from "react"

import { useParams } from "react-router-dom"

import Navbar from "../../components/Navbar"

import ProductCard from "../../components/products/ProductCard"

import ShopSidebar from "../../components/shop/ShopSidebar"

import { products } from "../../data/products"

const CategoryProducts = () => {

  const { category } = useParams()

  const [sortBy, setSortBy] = useState("best-selling")

  const filteredProducts = products
    .filter((item) => item.category === category)
    .sort((a, b) => {

      const aPrice = a.variants?.[0]?.price || 0
      const bPrice = b.variants?.[0]?.price || 0

      // LOW TO HIGH
      if (sortBy === "low") {
        return aPrice - bPrice
      }

      // HIGH TO LOW
      if (sortBy === "high") {
        return bPrice - aPrice
      }

      // BEST SELLING
      if (sortBy === "best-selling") {
        return (b.sales || 0) - (a.sales || 0)
      }

      return 0
    })

  return (

    <div className="bg-[#f8f8f8] min-h-screen">

      {/* NAVBAR */}

      <Navbar />

      <div className="max-w-7xl mx-auto px-6 py-14">

        {/* TOP SECTION */}

        <div className="flex items-center justify-between mb-10">

          {/* TITLE */}

          <div>

            <h1 className="text-4xl font-bold capitalize">
              {category.replace("-", " ")}
            </h1>

            <p className="text-gray-500 mt-2">
              {filteredProducts.length} Products Available
            </p>

          </div>

          {/* SORT */}

          <div>

            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="bg-white border border-gray-200 rounded-xl px-5 py-3 outline-none shadow-sm"
            >

              <option value="best-selling">
                Best Selling
              </option>

              <option value="low">
                Price: Low to High
              </option>

              <option value="high">
                Price: High to Low
              </option>

            </select>

          </div>

        </div>

        {/* MAIN LAYOUT */}

        <div className="flex gap-8">

          {/* SIDEBAR */}

          <div className="w-[260px] shrink-0">

            <ShopSidebar />

          </div>

          {/* PRODUCTS */}

          <div className="flex-1">

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">

              {filteredProducts.map((product) => (

                <ProductCard
                  key={product.id}
                  product={product}
                />

              ))}

            </div>

          </div>

        </div>

      </div>

    </div>

  )
}

export default CategoryProducts