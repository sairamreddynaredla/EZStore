import { useParams } from "react-router-dom";
import dogBreedsDetails from "../../data/dogBreedsDetails";
import breedData from "../../data/breeds";
import BreedDetailsLayout from "../../components/breeds/BreedDetailsLayout";

const BreedDetails = () => {
  const { slug } = useParams();
  // Try to find breed in detailed dog data first
  const breed = dogBreedsDetails.find((item) => item.slug === slug);
  if (breed) {
    return (
      <div className="max-w-6xl mx-auto px-6 py-10">
        <BreedDetailsLayout
          banner={breed.banner}
          overview={breed.overview}
          atAGlance={breed.atAGlance}
          sections={breed.sections}
          trivia={breed.trivia}
          faqs={breed.faqs}
          breedsList={breed.breedsList}
        />
      </div>
    );
  }

  // If not found, try to find in generic breed data
  const genericBreed = breedData.find((item) => item.slug === slug);
  if (!genericBreed) {
    return (
      <div className="text-center py-20 text-3xl font-bold">
        Breed Not Found
      </div>
    );
  }

  // Generic details layout for non-dog breeds or dogs without detailed data
  return (
    <div className="max-w-2xl mx-auto px-6 py-10">
      <div className="text-center">
        <img src={genericBreed.image} alt={genericBreed.name} className="w-48 h-48 rounded-full object-cover mx-auto mb-6 border-4 border-orange-200 shadow-lg" />
        <h2 className="text-4xl font-bold mb-2">{genericBreed.name}</h2>
        <div className="flex justify-center gap-2 mb-4">
          {genericBreed.traits && genericBreed.traits.map((trait, idx) => (
            <span key={idx} className="bg-orange-100 text-orange-700 px-3 py-1 rounded-full text-sm font-semibold">{trait}</span>
          ))}
        </div>
        {genericBreed.description && <p className="mb-4 text-lg">{genericBreed.description}</p>}
      </div>
      {genericBreed.info && (
        <div className="bg-gray-50 rounded-lg p-4 mb-4">
          <h3 className="font-bold mb-2">At a Glance</h3>
          <ul className="grid grid-cols-2 gap-2">
            {Object.entries(genericBreed.info).map(([label, value]) => (
              <li key={label}><strong>{label.charAt(0).toUpperCase() + label.slice(1)}:</strong> {value}</li>
            ))}
          </ul>
        </div>
      )}
      {genericBreed.nutrition && (
        <div className="mb-4">
          <h3 className="font-bold mb-1">Nutrition</h3>
          <p>{genericBreed.nutrition.description}</p>
        </div>
      )}
      {genericBreed.grooming && (
        <div className="mb-4">
          <h3 className="font-bold mb-1">Grooming</h3>
          <p>{genericBreed.grooming.description}</p>
        </div>
      )}
      {genericBreed.training && (
        <div className="mb-4">
          <h3 className="font-bold mb-1">Training</h3>
          <p>{genericBreed.training.title}</p>
        </div>
      )}
      {genericBreed.lifestyle && (
        <div className="mb-4">
          <h3 className="font-bold mb-1">Lifestyle</h3>
          <p>{genericBreed.lifestyle.title}</p>
        </div>
      )}
      {genericBreed.faq && genericBreed.faq.length > 0 && (
        <div className="mb-4">
          <h3 className="font-bold mb-1">FAQs</h3>
          <ul>
            {genericBreed.faq.map((item, idx) => (
              <li key={idx} className="mb-2"><strong>Q:</strong> {item.question}<br /><strong>A:</strong> {item.answer}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default BreedDetails;